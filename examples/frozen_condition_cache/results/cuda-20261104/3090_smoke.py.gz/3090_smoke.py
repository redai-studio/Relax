"""Small CUDA regressions for the submission sources; no model loading."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
import traceback
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    args = parser.parse_args()
    started = time.monotonic()
    paths = {
        "condition_cache": args.source_root / "relax/models/condition_cache.py",
        "processing": args.source_root / "relax/models/sensenova/processing.py",
    }
    report = {
        "schema": 1,
        "scope": "CUDA position and real condition-cache device/ownership/bounds regression; no model/SFT forward",
        "physical_gpu_index": 1,
        "source_sha256": {
            name: hashlib.sha256(path.read_bytes()).hexdigest()
            for name, path in paths.items()
        },
        "checks": [],
    }
    caches = []
    try:
        import torch
        import torchvision

        # Import the two unchanged modules without importing model registries.
        sys.path.insert(0, str(paths["condition_cache"].parent))
        sys.path.insert(0, str(paths["processing"].parent))
        from condition_cache import ConditionFeatureCache
        from processing import build_abs_positions_from_grid_hw

        assert torch.cuda.device_count() == 1, (
            "The container must expose only the selected GPU"
        )
        assert torch.cuda.is_available()
        report.update(
            torch=torch.__version__,
            torchvision=torchvision.__version__,
            cuda_runtime=torch.version.cuda,
            device=torch.cuda.get_device_name(0),
        )
        torch.cuda.reset_peak_memory_stats()
        grid = torch.tensor([[2, 2], [1, 3]], device="cpu")
        x, y = build_abs_positions_from_grid_hw(grid, device="cuda")
        assert (
            x.device.type == "cuda"
            and y.device == x.device
            and grid.device.type == "cpu"
        )
        assert x.cpu().tolist() == [0, 1, 0, 1, 0, 1, 2]
        assert y.cpu().tolist() == [0, 0, 1, 1, 0, 0, 0]
        report["checks"].append(
            {"name": "existing_abs_positions_cuda_case", "passed": True}
        )

        for storage, source_device in (("cpu", "cuda"), ("cuda", "cpu")):
            cache = ConditionFeatureCache(
                1 << 20, storage_device=storage, max_entries=8
            )
            caches.append(cache)
            for dtype in (
                torch.float32,
                torch.float16,
                torch.bfloat16,
                torch.int64,
                torch.bool,
            ):
                values = torch.arange(64, device=source_device).reshape(8, 8).T[::2, :]
                source = (
                    (values % 2 == 0) if dtype == torch.bool else values.to(dtype=dtype)
                )
                expected = source.cpu().clone()
                payload = {
                    "features": source,
                    "nested": (
                        torch.tensor([2, 7], device=source_device),
                        [None, "fixed"],
                    ),
                }
                key = str(dtype)
                assert cache.put(key, payload)
                source.zero_()
                first = cache.get(key, device="cuda")
                assert first["features"].device.type == "cuda"
                assert (
                    first["features"].dtype == dtype
                    and first["features"].is_contiguous()
                )
                assert torch.equal(
                    first["features"].cpu().contiguous().view(torch.uint8),
                    expected.contiguous().view(torch.uint8),
                )
                assert torch.equal(first["nested"][0].cpu(), torch.tensor([2, 7]))
                first["features"].zero_()
                first["nested"][0].zero_()
                second = cache.get(key, device="cpu")
                assert (
                    second["features"].device.type == "cpu"
                    and second["features"].dtype == dtype
                )
                assert torch.equal(
                    second["features"].contiguous().view(torch.uint8),
                    expected.contiguous().view(torch.uint8),
                )
                assert torch.equal(second["nested"][0], torch.tensor([2, 7]))
                assert second["nested"][1] == [None, "fixed"]
                assert cache.stats()["bytes"] <= cache.max_bytes
                report["checks"].append(
                    {
                        "name": "cache_cross_device_private_copies",
                        "storage": storage,
                        "source_device": source_device,
                        "dtype": str(dtype),
                        "passed": True,
                    }
                )
            stats = cache.stats()
            assert stats["h2d_bytes"] > 0 and stats["d2h_bytes"] > 0
            cache.close()
            assert (
                cache.stats()["bytes"] == 0
                and cache.stats()["entries"] == 0
                and cache.stats()["closed"]
            )
            try:
                cache.get("closed")
            except RuntimeError:
                pass
            else:
                raise AssertionError("Closed cache remained usable")
            report["checks"].append(
                {
                    "name": "cache_close_releases_payload",
                    "storage": storage,
                    "passed": True,
                }
            )

        bounded = ConditionFeatureCache(4096, storage_device="cuda", max_entries=1)
        caches.append(bounded)
        assert bounded.put(
            "first", torch.arange(256, device="cuda", dtype=torch.float32)
        )
        assert bounded.put(
            "second", torch.arange(256, device="cpu", dtype=torch.float32)
        )
        assert bounded.get("first", device="cpu") is None
        assert bounded.stats()["evictions"] == 1 and bounded.stats()["bytes"] <= 4096
        assert not bounded.put("oversize", torch.ones(2048, device="cuda"))
        assert bounded.stats()["oversized"] == 1 and bounded.stats()["bytes"] <= 4096
        try:
            bounded.put("trainable", torch.ones(8, device="cuda", requires_grad=True))
        except ValueError:
            pass
        else:
            raise AssertionError("Trainable features entered the frozen cache")
        bounded.close()
        assert bounded.stats()["bytes"] == 0
        report["checks"].append(
            {
                "name": "cuda_lru_byte_budget_oversize_and_trainable_rejection",
                "passed": True,
            }
        )
        torch.cuda.synchronize()
        report.update(
            peak_cuda_allocated=torch.cuda.max_memory_allocated(),
            peak_cuda_reserved=torch.cuda.max_memory_reserved(),
        )
        assert report["peak_cuda_allocated"] < 2 * 1024**3
        report["passed"] = True
    except BaseException as error:
        report.update(passed=False, error=repr(error), traceback=traceback.format_exc())
    finally:
        for cache in caches:
            cache.close()
        report["elapsed_seconds"] = time.monotonic() - started
        report["all_caches_closed"] = all(
            cache.stats()["closed"] and cache.stats()["bytes"] == 0 for cache in caches
        )
    print("RESULT_JSON=" + json.dumps(report, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
